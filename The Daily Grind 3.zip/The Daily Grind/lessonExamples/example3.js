function doPreincrement() {
let y = 6;
let x = ++y;
document.getElementById("demo1").innerHTML = y;
document.getElementById("demo2").innerHTML = x;
}

function doPostincrement() {
    let y = 6;
    let x = y++;
    document.getElementById("demo3").innerHTML = y;
    document.getElementById("demo4").innerHTML = x;
    }
    
    