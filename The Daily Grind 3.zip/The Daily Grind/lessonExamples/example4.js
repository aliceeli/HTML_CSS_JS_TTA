function showDate() {
    let d = new Date();
    document.getElementById("demo").innerHTML = d;
}